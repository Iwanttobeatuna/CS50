#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int number;
    struct node *next;
}
node;

int main(void)
{
    node *list = NULL;

    while (true)
    {
        int x = get_int("Number: ");
        if (x == INT_MAX)
        {
            printf("\n");
            break;
        }
        // TODO: Allocate a new node.
				// TODO: Add new node to head of linked list.
        
        node *n = malloc (sizeof(node));


    }

	// TODO: Print all nodes.
	// TODO: Free all nodes.

}